package com.example.lab_f3_trannguyenducanh_241a010625;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.textfield.TextInputEditText;

public class MainActivity extends AppCompatActivity {

    private TextInputEditText edtFullName;
    private Spinner spinnerSubject;
    private RadioGroup radioGroupTraining;
    private CheckBox cbMorning, cbAfternoon, cbEvening;
    private Button btnSubmit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Ánh xạ các thành phần giao diện
        edtFullName = findViewById(R.id.edtFullName);
        spinnerSubject = findViewById(R.id.spinnerSubject);
        radioGroupTraining = findViewById(R.id.radioGroupTraining);
        cbMorning = findViewById(R.id.cbMorning);
        cbAfternoon = findViewById(R.id.cbAfternoon);
        cbEvening = findViewById(R.id.cbEvening);
        btnSubmit = findViewById(R.id.btnSubmit);

        // Cấu hình dữ liệu cho Spinner (Danh sách môn học)
        String[] subjects = {
                "Lập trình trên các thiết bị di động",
                "Cơ sở dữ liệu",
                "Trí tuệ nhân tạo",
                "Kiểm thử phần mềm"
        };
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, subjects);
        spinnerSubject.setAdapter(adapter);

        // Xử lý sự kiện khi bấm nút Đăng ký
        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String fullName = edtFullName.getText().toString().trim();
                if (fullName.isEmpty()) {
                    edtFullName.setError("Vui lòng nhập họ tên");
                    return;
                }

                String selectedSubject = spinnerSubject.getSelectedItem().toString();

                // Lấy hệ đào tạo được chọn
                int selectedRbId = radioGroupTraining.getCheckedRadioButtonId();
                String trainingSystem = (selectedRbId == R.id.rbChinhQuy) ? "Chính quy" : "Vừa làm vừa học";

                // Kiểm tra các buổi học được chọn
                StringBuilder sessions = new StringBuilder();
                if (cbMorning.isChecked()) sessions.append("Sáng ");
                if (cbAfternoon.isChecked()) sessions.append("Chiều ");
                if (cbEvening.isChecked()) sessions.append("Tối ");

                if (sessions.length() == 0) {
                    Toast.makeText(MainActivity.this, "Vui lòng chọn ít nhất một buổi học!", Toast.LENGTH_SHORT).show();
                    return;
                }

                // Hiển thị kết quả (hoặc chuyển màn hình tùy yêu cầu bài tập)
                String result = "Đăng ký thành công!\n" +
                        "Họ tên: " + fullName + "\n" +
                        "Môn: " + selectedSubject + "\n" +
                        "Hệ: " + trainingSystem + "\n" +
                        "Buổi: " + sessions.toString();

                Toast.makeText(MainActivity.this, result, Toast.LENGTH_LONG).show();
            }
        });
    }
}